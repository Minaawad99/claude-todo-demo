// ── «إزاي بيحصل المد والجزر؟» — drawings. Shapes follow the «طب إزاي؟» reference (sheet v14) and real references
// (refs/SOURCES.md): globes are projected from real coastlines (Natural Earth 110m via ../../lib/geo.min.js);
// the beach is an isometric cut-away block with a sloping sand bed, a wooden pier on posts and a tide staff.

// ── isometric beach ──
// SAND_*, WOOD*, SEA_*, OCEAN, LAND, MOONC and globe / moon / sun / bulge / measure / tag come from the shared helpers.
function zs(x) { return 48 - 0.23 * x; }   // sand surface height along the shore normal (x: land 0 → sea 620)
function isoP(o, x, y, z) { return [o.ox + (x - y) * 0.866 * o.s, o.oy + (x + y) * 0.5 * o.s - z * o.s]; }
function ipoly(o, pts, fill, sw, ex) { return '<path d="' + pts.map(function (p, i) { var q = isoP(o, p[0], p[1], p[2]); return (i ? "L" : "M") + f(q[0]) + " " + f(q[1]); }).join(" ") + ' Z" fill="' + fill + '" stroke="' + INK + '" stroke-width="' + (sw == null ? 1.6 : sw) + '" stroke-linejoin="round"' + (ex || "") + '/>'; }
function iline(o, a, b, col, w, ex) { var p = isoP(o, a[0], a[1], a[2]), q = isoP(o, b[0], b[1], b[2]); return '<path d="M' + f(p[0]) + ' ' + f(p[1]) + ' L' + f(q[0]) + ' ' + f(q[1]) + '" stroke="' + (col || INK) + '" stroke-width="' + (w || 1.4) + '" fill="none"' + (ex || "") + '/>'; }
function ibox(o, x, y, z0, z1, w, d, fillT, fillL, fillR) {   // an upright box (post) footprint w×d at (x,y) from z0 to z1
  if (z1 <= z0) return "";
  return ipoly(o, [[x, y + d, z0], [x + w, y + d, z0], [x + w, y + d, z1], [x, y + d, z1]], fillL || WOOD_D, 1.2) +
         ipoly(o, [[x + w, y, z0], [x + w, y + d, z0], [x + w, y + d, z1], [x + w, y, z1]], fillR || WOOD, 1.2) +
         ipoly(o, [[x, y, z1], [x + w, y, z1], [x + w, y + d, z1], [x, y + d, z1]], fillT || "#c69a6c", 1.2);
}
var PX = [150, 220, 290, 360, 430, 500, 570], PY = [118, 158];
// the whole beach. zw = water level (-48 low … +18 high), t = time (waves), o = {ox, oy, s}, opt: {boat, staffHi, umbrella}
function beach(o, zw, t, opt) {
  opt = opt || {}; var s = "", B = -150, X1 = 620, Y1 = 280, xw = Math.max(0, Math.min(X1, (48 - zw) / 0.23));
  // sand block: top, front cut face with strata, sea-side face
  s += ipoly(o, [[0, 0, zs(0)], [X1, 0, zs(X1)], [X1, Y1, zs(X1)], [0, Y1, zs(0)]], SAND_TOP, 1.8);
  var hiX = (48 - 18) / 0.23;   // the high-water line: wet, darker sand below it
  if (xw > hiX) s += ipoly(o, [[hiX, 0, zs(hiX)], [xw, 0, zs(xw)], [xw, Y1, zs(xw)], [hiX, Y1, zs(hiX)]], WET, 0);
  var front = [], k; for (k = 0; k <= 12; k++) front.push([X1 * k / 12, 0, zs(X1 * k / 12)]);
  s += ipoly(o, front.concat([[X1, 0, B], [0, 0, B]]), SAND_SIDE, 1.8);
  [-26, -58, -96].forEach(function (dz, j) { var pts = []; for (k = 0; k <= 12; k++) pts.push([X1 * k / 12, 0, Math.max(B + 8, zs(X1 * k / 12) + dz)]);
    s += '<path d="' + pts.map(function (p, i) { var q = isoP(o, p[0], p[1], p[2]); return (i ? "L" : "M") + f(q[0]) + " " + f(q[1]); }).join(" ") + '" stroke="' + STRATA + '" stroke-width="' + (2.2 - j * .4) + '" fill="none" stroke-dasharray="' + (j ? "6 5" : "none") + '"/>'; });
  s += ipoly(o, [[X1, 0, zs(X1)], [X1, Y1, zs(X1)], [X1, Y1, B], [X1, 0, B]], STRATA, 1.8) + G("", ipoly(o, [[X1, 0, zs(X1)], [X1, Y1, zs(X1)], [X1, Y1, B], [X1, 0, B]], "url(#hatch)", 0), 1);
  // umbrella and towel on the dry sand
  if (opt.umbrella !== false) {
    s += ipoly(o, [[40, 150, zs(40) + .5], [100, 150, zs(100) + .5], [100, 190, zs(100) + .5], [40, 190, zs(40) + .5]], "#c96a4a", 1.2);
    var u0 = isoP(o, 70, 90, zs(70)), u1 = isoP(o, 70, 90, zs(70) + 80);
    s += '<path d="M' + f(u0[0]) + ' ' + f(u0[1]) + ' L' + f(u1[0]) + ' ' + f(u1[1]) + '" stroke="' + INK + '" stroke-width="' + f(2.4 * o.s) + '"/>';
    s += '<path d="M' + f(u1[0] - 46 * o.s) + ' ' + f(u1[1] + 18 * o.s) + ' Q' + f(u1[0]) + ' ' + f(u1[1] - 26 * o.s) + ' ' + f(u1[0] + 46 * o.s) + ' ' + f(u1[1] + 18 * o.s) + ' Z" fill="#e9e1cc" stroke="' + INK + '" stroke-width="1.6"/>' +
         '<path d="M' + f(u1[0] - 15 * o.s) + ' ' + f(u1[1] + 16 * o.s) + ' Q' + f(u1[0]) + ' ' + f(u1[1] - 22 * o.s) + ' ' + f(u1[0] + 15 * o.s) + ' ' + f(u1[1] + 16 * o.s) + ' Z" fill="' + ORANGE + '" stroke="' + INK + '" stroke-width="1.2"/>';
  }
  // pier posts: the part under water first (the sea is drawn over it)
  var posts = function (under) { var r = ""; PY.forEach(function (py) { PX.forEach(function (px) { var z0 = zs(px) - 10, top = 58;
    r += under ? ibox(o, px, py, z0, Math.min(top, zw), 9, 9) : ibox(o, px, py, Math.max(z0, zw), top, 9, 9); }); }); return r; };
  s += posts(true);
  // the sea: top, front cut face, sea-side face, waves running to the shore and a foam line
  if (xw < X1) {
    var wf = [[xw, 0, zw], [X1, 0, zw], [X1, 0, zs(X1)]]; for (k = 12; k >= 0; k--) { var xx = xw + (X1 - xw) * k / 12; wf.push([xx, 0, zs(xx)]); }
    s += '<g opacity=".93">' + ipoly(o, wf, SEA_SIDE, 1.8) + ipoly(o, [[X1, 0, zw], [X1, Y1, zw], [X1, Y1, zs(X1)], [X1, 0, zs(X1)]], "#5d7c90", 1.8) +
         ipoly(o, [[xw, 0, zw], [X1, 0, zw], [X1, Y1, zw], [xw, Y1, zw]], SEA_TOP, 1.8) + '</g>';
    if (!opt.calm) for (k = 0; k < 6; k++) { var wx = X1 - ((k * 64 + t * 48) % Math.max(60, X1 - xw - 10)); if (wx < xw + 8) continue;
      for (var yy = 18; yy < Y1 - 30; yy += 64) s += iline(o, [wx, yy + (k % 2) * 30, zw], [wx, yy + 30 + (k % 2) * 30, zw], "#e8eef0", 2.2, ' stroke-linecap="round"'); }
    s += iline(o, [xw + 3, 4, zw], [xw + 3, Y1 - 4, zw], "#f6f3ea", 3, ' stroke-linecap="round"');
  }
  s += posts(false);
  // deck: planks across the posts
  s += ipoly(o, [[130, 110, 58], [X1 - 10, 110, 58], [X1 - 10, 176, 58], [130, 176, 58]], "#c69a6c", 1.8) + ipoly(o, [[130, 176, 58], [X1 - 10, 176, 58], [X1 - 10, 176, 50], [130, 176, 50]], WOOD_D, 1.4);
  for (k = 150; k < X1 - 10; k += 22) s += iline(o, [k, 110, 58], [k, 176, 58], WOOD_D, 1);
  // tide staff on the sea-end post: white board, red marks every 10, the waterline crossing it
  var sx = 545, sy = 178;
  s += ipoly(o, [[sx, sy, -60], [sx + 16, sy, -60], [sx + 16, sy, 52], [sx, sy, 52]], "#f4efe3", 1.4);
  for (k = -60; k < 50; k += 10) s += ipoly(o, [[sx, sy, k], [sx + (k % 20 ? 8 : 16), sy, k], [sx + (k % 20 ? 8 : 16), sy, k + 3], [sx, sy, k + 3]], k >= -10 && opt.staffHi ? ORANGE : INK, 0);
  // the boat: sits on the sand at low water, floats at high water
  if (opt.boat !== false) {
    var bx = 300, bz = Math.max(zs(bx + 40) + 6, zw + 4), tilt = zw + 4 < zs(bx + 40) + 6 ? 0.18 : 0.04 * Math.sin(t * 1.6);
    var hull = [[bx, 40, bz + 10], [bx + 90, 40, bz + 10 + tilt * 40], [bx + 76, 40, bz - 4 + tilt * 30], [bx + 10, 40, bz - 4]];
    s += ipoly(o, [[bx, 40, bz + 10], [bx + 90, 40, bz + 10 + tilt * 40], [bx + 90, 78, bz + 10 + tilt * 40], [bx, 78, bz + 10]], "#5a4636", 1.6) +
         ipoly(o, [[bx + 8, 46, bz + 10], [bx + 82, 46, bz + 10 + tilt * 36], [bx + 82, 72, bz + 10 + tilt * 36], [bx + 8, 72, bz + 10]], "#8a6a4c", 1) +
         ipoly(o, hull.map(function (p) { return [p[0], 78, p[2]]; }), "#3f6a7e", 1.6) + ipoly(o, [[bx + 10, 78, bz + 4], [bx + 80, 78, bz + 4 + tilt * 34], [bx + 80, 78, bz + 7 + tilt * 36], [bx + 10, 78, bz + 7]], "#e7e1d1", 0);
  }
  return s;
}
// ── the beach from the side (eye level, a cut through the sand bed), 608 × 520 box. zw = water level (-46 low … +16 high).
// The sea climbs the sand slope at high water and leaves wet sand at low water; the tide staff shows the level.
function ys(x) { return 250 + 0.36 * x; }   // sand surface (y grows downward)
function beachSide(zw, t, opt) {
  opt = opt || {}; var W = 608, H = 520, yw = 360 - zw * 2.3, xw = Math.max(0, (yw - 250) / 0.36), s = "", k, x;
  var sand = "M0 " + f(ys(0)); for (k = 1; k <= 16; k++) { x = W * k / 16; sand += " L" + f(x) + " " + f(ys(x) + 3 * Math.sin(x * .05)); }
  s += '<path d="' + sand + ' L' + W + ' ' + H + ' L0 ' + H + ' Z" fill="' + SAND_SIDE + '" stroke="' + INK + '" stroke-width="2.2" stroke-linejoin="round"/>';
  s += '<path d="' + sand + ' L' + W + ' ' + H + ' L0 ' + H + ' Z" fill="url(#hatch)" opacity=".7"/>';
  [34, 78, 130].forEach(function (dz, j) { var d = ""; for (k = 0; k <= 16; k++) { x = W * k / 16; d += (k ? " L" : "M") + f(x) + " " + f(Math.min(H - 6, ys(x) + dz)); } s += '<path d="' + d + '" stroke="' + STRATA + '" stroke-width="' + (2.4 - j * .5) + '" fill="none"' + (j ? ' stroke-dasharray="7 6"' : "") + '/>'; });
  for (k = 0; k < 26; k++) { var px = hash(k) * W, py = ys(px) + 12 + hash(k + 40) * 150; if (py < H - 8) s += '<circle cx="' + f(px) + '" cy="' + f(py) + '" r="' + f(2 + hash(k + 9) * 3) + '" fill="' + STRATA + '"/>'; }
  // wet sand between the low-water line and the highest the sea reached
  var hiX = (360 - 16 * 2.3 - 250) / 0.36; if (xw > hiX) s += '<path d="M' + f(hiX) + ' ' + f(ys(hiX)) + ' L' + f(xw) + ' ' + f(ys(xw)) + ' L' + f(xw) + ' ' + f(ys(xw) + 7) + ' L' + f(hiX) + ' ' + f(ys(hiX) + 7) + ' Z" fill="' + WET + '"/>';
  // umbrella and towel on the dry sand
  if (opt.umbrella !== false) s += '<path d="M60 ' + f(ys(60)) + ' L66 ' + f(ys(60) - 120) + '" stroke="' + INK + '" stroke-width="3"/>' + '<path d="M6 ' + f(ys(60) - 104) + ' Q66 ' + f(ys(60) - 160) + ' 126 ' + f(ys(60) - 104) + ' Z" fill="#e9e1cc" stroke="' + INK + '" stroke-width="2"/><path d="M46 ' + f(ys(60) - 108) + ' Q66 ' + f(ys(60) - 150) + ' 86 ' + f(ys(60) - 108) + ' Z" fill="' + ORANGE + '" stroke="' + INK + '" stroke-width="1.6"/>' +
    '<path d="M18 ' + f(ys(18) - 3) + ' L110 ' + f(ys(110) - 3) + '" stroke="#c96a4a" stroke-width="6" stroke-linecap="round"/>';
  // pier: posts into the sand (drawn before the sea so the water covers their feet), a plank deck on top
  var posts = ""; for (x = 250; x < W; x += 66) posts += R(x, 214, 13, ys(x) + 26 - 214, WOOD_D, 1.8) + '<rect x="' + f(x + 8) + '" y="214" width="5" height="' + f(ys(x) + 26 - 214) + '" fill="' + INK + '" opacity=".2"/>';
  s += posts;
  // the sea: water body over the slope, a lighter surface band, moving wave crests, foam at the shoreline
  if (xw < W) {
    var top = "M" + f(xw) + " " + f(yw); for (x = xw; x <= W + 1; x += 8) top += " L" + f(x) + " " + f(yw + 4 * Math.sin((x - t * 70) * .045));
    var body = top + " L" + W + " " + f(ys(W)); for (k = 16; k >= 0; k--) { x = xw + (W - xw) * k / 16; body += " L" + f(x) + " " + f(ys(x)); } body += " Z";
    s += '<path d="' + body + '" fill="' + SEA_SIDE + '" opacity=".88" stroke="' + INK + '" stroke-width="2"/>';
    s += '<path d="' + top + ' L' + W + ' ' + f(yw + 16) + ' L' + f(xw + 16) + ' ' + f(yw + 16) + ' Z" fill="' + SEA_TOP + '" opacity=".75"/>';
    for (k = 0; k < 7; k++) { var cx2 = xw + 30 + ((k * 92 + t * 70) % Math.max(80, W - xw - 30)); s += '<path d="M' + f(cx2 - 12) + ' ' + f(yw + 30 + (k % 3) * 22) + ' q12 -5 24 0" stroke="#d6e2e6" stroke-width="2.4" fill="none" stroke-linecap="round" opacity=".8"/>'; }
    s += '<path d="M' + f(xw - 6) + ' ' + f(yw + 1) + ' q8 -6 18 -2 t18 0" stroke="#f6f3ea" stroke-width="4" fill="none" stroke-linecap="round"/>';
  }
  s += R(230, 200, W - 222, 16, "#c69a6c", 2) + R(230, 216, W - 222, 6, WOOD_D, 1.4); for (x = 252; x < W; x += 24) s += '<path d="M' + x + ' 200 v16" stroke="' + WOOD_D + '" stroke-width="1.2"/>';
  // the tide staff on the sea-end post: white board, red and black marks, the level number beside the waterline
  var sx = 520; s += R(sx, 150, 26, 300, "#f4efe3", 1.8);
  for (k = 0; k < 15; k++) { var my = 158 + k * 20; s += R(sx, my, k % 2 ? 13 : 26, 6, my > yw - 2 && opt.staffHi ? ORANGE : INK, 0); }
  // the boat: a rowing boat in profile, aground and tilted at low water, floating level at high water
  if (opt.boat !== false) {
    var bx = 360, ground = ys(bx + 55) - 2, fl = yw + 6, by = Math.min(fl, ground), tilt = fl > ground ? -9 : 2 * Math.sin(t * 1.8);
    s += G("translate(" + f(bx) + " " + f(by) + ") rotate(" + f(tilt) + " 55 0)", '<path d="M0 -26 L110 -26 L96 4 Q55 12 14 4 Z" fill="#3f6a7e" stroke="' + INK + '" stroke-width="2.2" stroke-linejoin="round"/><path d="M4 -22 L106 -22" stroke="#e7e1d1" stroke-width="4"/><path d="M30 -26 l-8 -16 M80 -26 l10 -14" stroke="' + WOOD_D + '" stroke-width="4" stroke-linecap="round"/>');
  }
  return s;
}
// the water level that a beach at angle a (radians from the Earth–Moon line) sees: high on both bulges, low at the sides
function levelAt(a) { return lerp(-46, 16, (Math.cos(2 * a) + 1) / 2); }

// ── globes, moon, sun, bulges ──
// three balls on an isometric strip toward the Moon (reference v14): positions p[] (0..1 along), colours, pull arrows
function track(t, k, cols, offs, arrows, labels) {
  var x0 = 70, y0 = 520, x1 = 470, y1 = 330, s = "";
  s += '<path d="M' + (x0 - 40) + ' ' + (y0 + 40) + ' L' + (x1 + 40) + ' ' + (y1 + 10) + ' L' + (x1 + 70) + ' ' + (y1 + 50) + ' L' + (x0 - 10) + ' ' + (y0 + 80) + ' Z" fill="#e6dcc5" stroke="' + INK + '" stroke-width="1.2" opacity=".9"/>';
  for (var g = 0; g <= 10; g++) { var u = g / 10; s += '<path d="M' + f(lerp(x0 - 40, x1 + 40, u)) + ' ' + f(lerp(y0 + 40, y1 + 10, u)) + ' l30 40" stroke="#cdbf9f" stroke-width="1"/>'; }
  s += moon(565, 260, 38);
  [0.12, 0.4, 0.68].forEach(function (p, i) {
    var q = clamp(p + (offs ? offs[i] : 0)), x = lerp(x0, x1, q), y = lerp(y0, y1, q) - 6 - 7 * Math.abs(Math.sin(t * 2.4 + i * 1.1));
    s += appear(at(k, i * .25, .3), '<ellipse cx="' + f(x + 6) + '" cy="' + f(y + 26) + '" rx="36" ry="11" fill="' + INK + '" opacity=".15"/>' + C(x, y, 36, cols[i], 2.4) + '<circle cx="' + f(x - 11) + '" cy="' + f(y - 12) + '" r="9" fill="#fff" opacity=".45"/>');
    if (arrows) { var pl = arrows[i] * (1 + .12 * Math.sin(t * 4 + i)); s += arrow(x + 30, y - 22, x + 30 + pl * .8, y - 22 - pl * .48, ORANGE, 5, at(k, .8 + i * .2, .4)); }
    if (labels && labels[i]) s += label(x, y + 30, x + 50, y + 110, labels[i], cols[i] === OCEAN ? BLUE : OLIVE, at(k, 1 + i * .3, .5), 22);
  });
  return s;
}
var ALEX = [29.9, 31.2];   // the viewer's beach (Alexandria)

// ── shots (one per idea; line numbers from script.txt) ──
// 4 · the Moon, 384,000 km away: Africa-facing globe on the left, the Moon on the right, the distance draws itself
shot(4, push(330, 400, 1.08, 0.96), function (u, d, t) {
  var k = at(u, .6, 1.4);
  return paper() + appear(at(u, 0, .4), globe(120, 400, 190, 12 + t * 1.6, 8)) + appear(at(u, .3, .4), moon(560, 400, 44)) +
    measure(320, 470, 515, 470, k, "", 0) + G("", N(count(384000, k), 420, 540, 44) + T("كيلو", 420, 582, 26, INK, 700), clamp(k * 3)) + label(560, 360, 520, 280, "القمر", OLIVE, at(u, .4, .5), 24);
});
// 5 · «قاعدة صغيرة»: a pinned rule card over the Moon and an empty strip
shot(5, push(320, 420, 1.0, 1.08), function (u, d, t) {
  return paper() + track(t, -1, [GREY, GREY, GREY]) + G("", '<rect x="150" y="150" width="340" height="150" fill="#f4ecdb" stroke="' + INK + '" stroke-width="2.4" transform="rotate(-3 320 225)"/>' +
    T("القريب", 320, 212, 40, ORANGE, 800) + T("بيتشد أكتر", 320, 262, 34, INK, 700) + C(320, 158, 9, ORANGE, 2), at(u, .3, .4));
});
// 6 · gravity weakens with distance: three balls, the pull arrows get shorter the farther they are
shot(6, push(320, 430, 1.05, 0.98), function (u, d, t) { return paper() + track(t, u, [GREY, GREY, GREY], null, [60, 95, 140]); });
// 7 · the Earth is big: 12,742 km across
shot(7, push(320, 380, 0.95, 1.05), function (u, d, t) {
  var k = at(u, .4, 1.2);
  return paper() + globe(320, 360, 215, 12 + t * 1.6, 8) + measure(105, 640, 535, 640, k, "") + G("", N(count(12742, k), 320, 712, 46) + T("كيلو", 320, 750, 24, INK, 700), clamp(k * 3));
});
// 8 · near water (blue) is closer → pulled more than the Earth (green)
shot(8, push(330, 420, 1.0, 1.08), function (u, d, t) { return paper() + track(t, u + 1, [OCEAN, LAND, GREY], null, [140, 95, 0], ["البحر اللي قدام", "الأرض", ""]); }, { tr: "in" });
// 9 · far water is pulled least and lags: the three drift apart
shot(9, push(330, 420, 1.08, 1.0), function (u, d, t) {
  var k = at(u, .3, d - .6); return paper() + track(t, 9, [OCEAN, LAND, OCEAN], [.08 * k, .03 * k, -.02 * k], [140, 95, 60], ["", "", "البحر اللي ورا"]);
});
// 10 · the result: the water stretches both ways (a bulge round the globe); thumbnail: a long watermelon
shot(10, push(330, 400, 0.9, 1.02), function (u, d, t) {
  var k = at(u, .3, 1.4); return paper() + bulge(300, 400, 200, k, 0) + globe(300, 400, 200, 12 + t * 1.6, 8) + moon(600, 400, 30) +
    iconBox(80, 90, 120, '<ellipse rx="44" ry="26" fill="#6f8a4a" stroke="' + INK + '" stroke-width="2"/><path d="M-40 -6 Q0 -22 40 -6 M-42 6 Q0 -6 42 6" stroke="#3f5a2a" stroke-width="4" fill="none"/>', at(u, 1, .3));
}, { tr: "out" });
// 11 · two bulges: one facing the Moon, one on the back
shot(11, push(320, 400, 1.0, 1.06), function (u, d, t) {
  return paper() + bulge(300, 400, 200, 1, 0) + globe(300, 400, 200, 12 + t * 1.6, 8) + moon(605, 400, 30) +
    label(530, 330, 470, 190, "انتفاخ", BLUE, at(u, .3, .5), 26) + label(40, 420, 90, 620, "انتفاخ تاني", BLUE, at(u, 1.1, .5), 26);
});
// 12 · «طب ليه البحر عندك بيعلى وينزل؟»: back to the beach, the staff, a question mark
shot(12, push(320, 430, 1.05, 1.0), function (u, d, t) { return paper() + G("translate(16 200)", beachSide(lerp(-30, 12, (Math.sin(t * 1.4) + 1) / 2), t, { staffHi: true })) + T("؟", 500, 250, 130, ORANGE, 800); }, { tr: "out" });
// 13–15 · seen from above the North Pole: the Earth turns inside the two bulges; the dot is your beach
function polar(u, t, op) {
  op = op || {}; var spin = op.spin == null ? t * 22 : op.spin, cx = op.cx || 290, cy = op.cy || 400, r = op.r || 175;
  var s = bulge(cx, cy, r, op.k == null ? 1 : op.k, op.ang || 0) + globe(cx, cy, r, -spin, 72, { dot: op.noDot ? null : ALEX }) + (op.noMoon ? "" : moon(op.mx || 600, op.my || cy, 30));
  return s;
}
function beachAngle(spin) { var p = GEO.globe(290, 400, 175, -spin, 72).project(ALEX); return p ? Math.atan2(p[1] - 400, p[0] - 290) : 0; }
shot(13, push(300, 400, 0.95, 1.05), function (u, d, t) {
  return paper() + polar(u, t) + draw("M150 170 A190 190 0 0 1 430 170", at(u, .3, .8), ORANGE, 5) + arrow(420, 160, 440, 185, ORANGE, 5, at(u, 1, .2));
});
shot(14, push(300, 420, 1.05, 1.0), function (u, d, t) {
  var a = beachAngle(t * 22), lv = levelAt(a), hi = lv > -15;
  return paper() + polar(u, t) + iconBox(450, 190, 250, G("translate(-125 -125) scale(.41) translate(0 40)", beachSide(lv, t, { umbrella: false, staffHi: true })), at(u, .2, .3)) +
    tag(hi ? "مد" : "جزر", 450, 360, at(u, .4, .3), 36, hi ? BLUE : ORANGE);
});
// 15 · twice a day each: a 24-hour dial with the four tides round it
hud(15, 16, function (u, t) {
  var s = '<circle cx="530" cy="110" r="78" fill="#f4ecdb" stroke="' + INK + '" stroke-width="2.4"/>';
  ["مد", "جزر", "مد", "جزر"].forEach(function (w, i) { var a = -Math.PI / 2 + i * Math.PI / 2, x = 530 + Math.cos(a) * 52, y = 110 + Math.sin(a) * 52; s += G("", T(w, x, y + 9, 22, i % 2 ? ORANGE : BLUE, 800), at(u, .2 + i * .25, .25)); });
  var h = u * 1.4; return s + '<path d="M530 110 L' + f(530 + Math.cos(h - Math.PI / 2) * 34) + ' ' + f(110 + Math.sin(h - Math.PI / 2) * 34) + '" stroke="' + INK + '" stroke-width="4" stroke-linecap="round"/>' + C(530, 110, 5, INK, 0) + T("24 ساعة", 530, 222, 22, INK, 700);
});
shot(15, push(300, 420, 1.0, 0.95), function (u, d, t) { return paper() + polar(u, t, { cx: 260 }); });
// 16 · every day the tide comes about 50 minutes later: a clock whose hand runs on past the hour
shot(16, push(320, 400, 1.05, 1.0), function (u, d, t) {
  var k = at(u, .5, 1.6), a = -Math.PI / 2 + k * (50 / 60) * Math.PI * 2, s = paper();
  s += C(320, 380, 190, "#f4ecdb", 3) + C(320, 380, 176, "none", 1.2);
  for (var i = 0; i < 60; i++) { var b = i / 60 * Math.PI * 2, r1 = i % 5 ? 166 : 154; s += '<path d="M' + f(320 + Math.cos(b) * r1) + ' ' + f(380 + Math.sin(b) * r1) + ' L' + f(320 + Math.cos(b) * 174) + ' ' + f(380 + Math.sin(b) * 174) + '" stroke="' + INK + '" stroke-width="' + (i % 5 ? 1.4 : 3) + '"/>'; }
  s += '<path d="M320 380 L' + f(320 + 160 * Math.cos(-Math.PI / 2)) + ' ' + f(380 + 160 * Math.sin(-Math.PI / 2)) + ' A160 160 0 ' + (k * 50 / 60 > .5 ? 1 : 0) + ' 1 ' + f(320 + 160 * Math.cos(a)) + ' ' + f(380 + 160 * Math.sin(a)) + ' Z" fill="' + ORANGE + '" opacity=".25"/>';
  s += '<path d="M320 380 L' + f(320 + Math.cos(a) * 150) + ' ' + f(380 + Math.sin(a) * 150) + '" stroke="' + INK + '" stroke-width="5" stroke-linecap="round"/><path d="M320 380 L' + f(320 + Math.cos(-Math.PI / 2 + k * .44) * 95) + ' ' + f(380 + Math.sin(-Math.PI / 2 + k * .44) * 95) + '" stroke="' + INK + '" stroke-width="8" stroke-linecap="round"/>' + C(320, 380, 9, INK, 0);
  return s + numBox("+" + count(50, k), 320, 640, at(u, .3, .3), 44) + G("", T("دقيقة", 320, 712, 30, INK, 800), at(u, .5, .3));
});
// 17 · because the Moon moves along its orbit, the Earth must turn a bit more to catch it (top view)
shot(17, push(320, 400, 0.92, 1.02), function (u, d, t) {
  var k = at(u, .3, d - .8), ma = -k * 0.42, s = paper();
  s += '<circle cx="250" cy="400" r="300" fill="none" stroke="' + INK + '" stroke-width="1.6" stroke-dasharray="8 8"/>';
  s += G("", moon(250 + 300 * Math.cos(0), 400, 30), .35) + moon(250 + 300 * Math.cos(ma), 400 + 300 * Math.sin(ma), 30);
  s += polar(u, t, { cx: 250, r: 120, k: .6, ang: ma * 180 / Math.PI, noMoon: true, spin: k * 380 });
  s += draw("M" + f(250 + 150) + " 400 A150 150 0 0 0 " + f(250 + 150 * Math.cos(ma)) + " " + f(400 + 150 * Math.sin(ma)), k, ORANGE, 6);
  return s + label(250 + 300 * Math.cos(ma), 370 + 300 * Math.sin(ma), 460, 120, "القمر بيتحرك", OLIVE, at(u, .6, .5), 24);
});
// 18 · the Sun pulls too, about half as strongly
shot(18, push(330, 400, 1.0, 1.06), function (u, d, t) {
  return paper() + sun(-40, 400, 170, t) + bulge(380, 400, 120, .45, 0, "#7a96aa") + globe(380, 400, 120, -t * 22, 72) + moon(600, 400, 24) +
    arrow(170, 400, 230, 400, ORANGE, 6, at(u, .5, .4)) + arrow(560, 400, 450, 400, ORANGE, 10, at(u, .3, .4)) + numBox("½", 250, 270, at(u, 1.1, .3), 54);
}, { tr: "out" });
// 19 · Sun, Earth and Moon in a line (new moon / full moon): the bulges add up, the tide is highest
shot(19, push(320, 400, 1.02, 0.96), function (u, d, t) {
  var k = at(u, .3, 1); return paper() + sun(-60, 400, 150, t) + bulge(360, 400, 120, lerp(.6, 1.35, k), 0) + globe(360, 400, 120, -t * 22, 72) + moon(590, 400, 26) +
    draw("M90 400 L620 400", at(u, .1, .6), ORANGE, 2.4, ' stroke-dasharray="10 8"') + iconBox(470, 130, 200, '<circle cx="-45" cy="-18" r="30" fill="#3d3a34" stroke="' + INK + '" stroke-width="2"/>' + moon(45, -18, 30) + T("محاق", -45, 50, 22, INK, 700) + T("بدر", 45, 50, 22, INK, 700) + T("أول الشهر · نصه", 0, 84, 18, MUTE, 600), at(u, .8, .3)) + tag("أعلى مد", 360, 650, at(u, 1.2, .3), 34, BLUE);
});
// 20 · at right angles: the Sun's pull fills the Moon's low tide, the bulge is weakest
shot(20, push(320, 420, 0.96, 1.04), function (u, d, t) {
  var k = at(u, .3, 1); return paper() + sun(-60, 420, 150, t) + bulge(360, 420, 120, .45, 0, "#7a96aa") + bulge(360, 420, 120, lerp(1, .55, k), 90) + globe(360, 420, 120, -t * 22, 72) + moon(360, 140, 26) +
    draw("M360 280 V170", at(u, .1, .5), ORANGE, 2.4, ' stroke-dasharray="10 8"') + draw("M220 420 H100", at(u, .1, .5), ORANGE, 2.4, ' stroke-dasharray="10 8"') + '<path d="M360 250 h-26 v26" stroke="' + ORANGE + '" stroke-width="2.4" fill="none" transform="translate(-150 144)"/>' + tag("أضعف مد", 360, 680, at(u, 1, .3), 34, BLUE);
});
// 21 · the myth: the Moon lifting only the water under it — crossed out
shot(21, push(300, 420, 1.12, 0.96), function (u, d, t) {
  var k = at(u, .2, .7); return paper() + globe(280, 420, 180, 12 + t * 1.6, 8) + moon(590, 420, 30) + '<path d="M455 ' + f(420 - 70 * k) + ' Q' + f(500 + 30 * k) + ' 420 455 ' + f(420 + 70 * k) + ' Z" fill="#5f7f97" stroke="' + INK + '" stroke-width="2.2"/>' +
    arrow(470, 420, 545 + 12 * Math.sin(t * 3), 420, ORANGE, 6, k) + wave(470, 300, 560, 300, t, BLUE, 6, 24, k, 3) + cross(500, 330, 1.5, at(u, d * .55, .5));
});
// 22 · it stretches the whole Earth; the water just shows it because it flows
shot(22, push(320, 400, 1.0, 1.06), function (u, d, t) {
  var k = at(u, .3, 1.2); return paper() + bulge(300, 400, 190, k, 0) + '<ellipse cx="300" cy="400" rx="' + f(190 * (1 + .06 * k)) + '" ry="190" fill="none" stroke="' + ORANGE + '" stroke-width="3" stroke-dasharray="10 7"/>' + globe(300, 400, 190, 12 + t * 1.6, 8) + moon(605, 400, 28) +
    label(300 + 190 * (1 + .06 * k), 470, 470, 650, "الأرض نفسها", ORANGE, at(u, .8, .5), 24) + label(560, 360, 500, 210, "المية", BLUE, at(u, 1.3, .5), 24);
}, { tr: "in" });
// 23 · «يعني من الآخر»: everything at once, labelled
shot(23, push(300, 400, 0.94, 1.02), function (u, d, t) {
  return paper() + polar(u, t) + label(600, 370, 560, 250, "القمر", OLIVE, at(u, .2, .4), 24) + label(500, 420, 470, 600, "انتفاخ", BLUE, at(u, .8, .4), 24) + label(80, 420, 120, 620, "انتفاخ", BLUE, at(u, 1.3, .4), 24);
}, { tr: "out" });
// 24 · the odd fact: the bulge runs ahead, brakes the Earth and nudges the Moon away (about 4 cm a year)
shot(24, push(320, 400, 1.0, 0.94), function (u, d, t) {
  var k = at(u, .3, d - .6), mx = 520 + 70 * k;
  return paper() + bulge(260, 400, 160, 1, -14) + globe(260, 400, 160, -t * 22, 72) + moon(mx, 400, 28) + draw("M130 210 A190 190 0 0 1 390 210", 1, INK, 4) + arrow(380, 200, 400, 225, INK, 4) +
    measure(520, 470, mx, 470, k, "") + G("", N("~4 cm", (520 + mx) / 2, 530, 34, ORANGE) + T("كل سنة", (520 + mx) / 2, 570, 22, INK, 700), at(u, 1, .4)) + iconBox(110, 120, 110, '<rect x="-30" y="-20" width="60" height="40" rx="6" fill="' + ORANGE + '" stroke="' + INK + '" stroke-width="2"/>' + T("فرامل", 0, 8, 18, "#fff", 800), at(u, .6, .3));
});

// ── opening card, bumper and summary art ──
window.SCENE = window.SCENE || {};
SCENE.intro = function (svg, t, li) {
  // line 0: a calm beach. line 1: the sea comes in over the sand, then goes out again. line 2: no wind (a crossed-out wind sign)
  var l1 = LN[1], k = clamp((t - l1.start) / Math.max(1, l1.end - l1.start)), lv = li === 0 ? -30 : li === 1 ? lerp(-30, 16, Math.sin(k * Math.PI)) : -30;
  var s = G("translate(0 120)", beachSide(lv, t, { staffHi: true }));
  if (li >= 1) s += iconBox(530, 70, 110, '<circle r="34" fill="#f4ecdb" stroke="' + INK + '" stroke-width="2"/><path d="M0 0 V-24 M0 0 L16 10" stroke="' + INK + '" stroke-width="4" stroke-linecap="round"/>' + T("6 ساعات", 0, 52, 15, INK, 700), ease((t - l1.start) / .4));
  if (li >= 2) { var u = t - LN[2].start; s += G("translate(90 90)", '<path d="M-56 -22 H14 C34 -22 38 -46 22 -48 C10 -50 6 -40 10 -34 M-56 0 H34 C58 0 60 -28 40 -30 M-56 22 H4 C24 22 26 44 12 46 C2 47 -2 38 2 33" fill="none" stroke="' + INK + '" stroke-width="5" stroke-linecap="round"/>', ease(u / .3)) + cross(90, 90, 1.1, ease((u - .4) / .4)); }
  return s;
};
SCENE.bumper = function (u, t) {
  var s = '<rect x="0" y="120" width="180" height="80" fill="' + SEA_TOP + '"/>';
  for (var k = 0; k < 6; k++) s += '<path d="M' + f(-40 + ((k * 40 + t * 55) % 230)) + ' ' + (132 + k * 10) + ' q10 -7 20 0 t20 0" stroke="#e8eef0" stroke-width="3" fill="none"/>';
  return s + moon(110 - 18 * Math.sin(t * .9), 82 - 10 * Math.cos(t * 1.1), 26);
};
SCENE.outro = function (svg, u, t) {
  var p = GEO.globe(230, 140, 92, -t * 22, 72).project(ALEX);
  return bulge(230, 140, 92, 1, 0) + globe(230, 140, 92, -t * 22, 72, { dot: ALEX }) + moon(530, 140, 26) +
    callout("1", 530, 90, ease(u / .3)) + callout("2", 370, 110, ease(u / .3 - .5)) + callout("3", 80, 110, ease(u / .3 - 1)) + (p ? callout("4", p[0] + 22, p[1] - 22, ease(u / .3 - 1.5)) : "");
};
